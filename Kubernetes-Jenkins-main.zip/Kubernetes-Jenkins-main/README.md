# k8s-jenkins
k8s-jenkins as container and pod
