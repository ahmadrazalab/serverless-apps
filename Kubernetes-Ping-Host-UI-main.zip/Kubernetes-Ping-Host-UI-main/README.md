# k8-ping-host
app that will check the connection in between kubernetes pod using port number 
