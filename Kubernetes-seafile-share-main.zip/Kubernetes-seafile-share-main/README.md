# k8s-seafile-share
from docker compose to kubernets deploy as file share app 
