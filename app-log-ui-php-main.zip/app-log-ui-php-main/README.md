# app-log-ui
Here we can see the logs in the webpage of application 100 lines 


# here we can see the logs in webpage for laravel php appliction 
- on domain logs.in
- or path based logs using logs.in/logs
- using nginx ht password to login while in public visit to securent the webpage         
