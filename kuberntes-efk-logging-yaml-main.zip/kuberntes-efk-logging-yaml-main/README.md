# kuberntes-efk-logging-yaml
