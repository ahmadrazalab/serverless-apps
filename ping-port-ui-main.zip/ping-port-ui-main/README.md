# ping-port
a kuberntes container that will be used to test the connection between source and destination on any port (eg: container to rds db on port 3306 )


# UI
Open the Ui on a decided port then put the hostname or ip of destination with its port then click test connection it will return the success of failure 
